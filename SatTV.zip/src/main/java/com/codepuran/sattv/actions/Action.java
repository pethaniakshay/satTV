package com.codepuran.sattv.actions;

public interface Action {
  void perform(long userId);
}
