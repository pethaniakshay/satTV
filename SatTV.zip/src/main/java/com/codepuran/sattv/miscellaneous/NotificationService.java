package com.codepuran.sattv.miscellaneous;

public class NotificationService {

  public static void sendEmailNotification() {
    System.out.println("Email notification sent successfully");
  }

  public static void sendSMSNotification() {
    System.out.println("SMS notification sent successfully");
  }
}
